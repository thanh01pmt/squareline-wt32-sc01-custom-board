### Folder structure
Exported Folder 
    |
    |libraries
    |    |
    |    |LovyanGFX    	
    |    |lv_conf.h
    |    |README.md (This file)
    |ui
         |ui.ino
         |ui.c
         |ui.h
         |... (other file) 

### Instruction
[1] Copy "LovyanGFX" folder to Arduino libraries folder (...\Arduino\libraries).
[2] Copy "lv_conf.h" file to Arduino libraries folder (...\Arduino\libraries). Make sure you install LVGL library before and have a "lvgl" folder in Arduino libraries folder.
